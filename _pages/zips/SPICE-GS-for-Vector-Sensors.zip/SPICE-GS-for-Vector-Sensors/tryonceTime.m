%{
# MATLAB Implementaton Code for "SPICE-GS" in [1] and [2]
These codes are hosted as a zip file on author's personal website: https://qilin-zhang.github.io/publications/, and author's contact: https://qilin-zhang.github.io/contact/.
# OS and software settings
This software was tested on MATLAB back in 2010. Also it is tested to be compatible with Free Open source alternative, GNU Octave Version: 4.2.2, on Ubuntru Linux 18.04 in 2019.
# Citations
If you find the codes helpful, please consider citing the follwing publications, 
[2] Fast implementation of sparse iterative covariance-based estimation for source localization
Zhang, Qilin, Habti Abeida, Ming Xue, William Rowe, and Jian Li. “Fast implementation of sparse iterative covariance-based estimation for source localization.” The Journal of the Acoustical Society of America 131, no. 2 (2012): 1249-1259. 

@article{zhang2012fast,
  title={Fast implementation of sparse iterative covariance-based estimation for source localization},
  author={Zhang, Qilin and Abeida, Habti and Xue, Ming and Rowe, William and Li, Jian},
  journal={The Journal of the Acoustical Society of America},
  volume={131},
  number={2},
  pages={1249--1259},
  year={2012},
  publisher={Acoustical Society of America}
}

preprint PDF link: https://qilin-zhang.github.io/_pages/pdfs/Fast_implementation_of_sparse_iterative_covariance-based_estimation_for_source_localization.pdf?raw=true

[1] Fast implementation of sparse iterative covariance-based estimation for array processing
Zhang, Qilin, Habti Abeida, Ming Xue, William Rowe, and Jian Li. “Fast implementation of sparse iterative covariance-based estimation for array processing.” In Signals, Systems and Computers (ASILOMAR), 2011 Conference Record of the Forty Fifth Asilomar Conference on, pp. 2031-2035. IEEE, 2011. 

@inproceedings{zhang2011fast,
  title={Fast implementation of sparse iterative covariance-based estimation for array processing},
  author={Zhang, Qilin and Abeida, Habti and Xue, Ming and Rowe, William and Li, Jian},
  booktitle={Signals, Systems and Computers (ASILOMAR), 2011 Conference Record of the Forty Fifth Asilomar Conference on},
  pages={2031--2035},
  year={2011},
  organization={IEEE}
}

preprint PDF link: https://qilin-zhang.github.io/_pages/pdfs/Fast_Implementation_of_Sparse_Iterative_Covariance-Based_Estimation_for_Array_Processing.pdf?raw=true

- Note: [2] is the extended journal version of [1].
# Where to start 
1. curve.m: This is the MATLAB/Octave script file to generate plots similar to Fig. 1(d)~(f) and Fig. 2 (b) in [2], the ''actual running time'' values will be different due to different hardware/software settings.
2. tryonceTime.m: In this function, DOA estimation figures are plotted, and actual running time values are recorded.
3. fun_slowSPICE_VSF_new.m: this function is the "direct implementation of SPICE" with Vector Sensor arrays.
4. fun_fastSPICE_VSF_new: the fast version, i.e., SPICE-GS with Vector Sensor arrays. 
5. generatorR_VSF.m: core G-S algorithm implementations, please refer to [2] for details. 
6. FFT4Tinv_c_VSF: core G-S algorithm implementations, please refer to [2] for details. 

# Disclaimer and License
MIT License
Copyright (c) 2010 Qilin Zhang
%}
function [slowSPICEtime ,fastSPICEtime] = tryonceTime(m)
% inputs: m: number of array elements, e.g., m = 32 or 64, etc.
% outputs: 
% --slowSPICEtime: actual running time of direct implmementation of SPICE algorithm
% --fastSPICEtime: actual running time of G-S factorization based implmementation of SPICE algorithm
%  



%%% beginning of control panel %%%
scansize  = 2000;
randseed = 1234321;
rand('seed',randseed);
randn('seed',randseed);
figpath   = 'MyNewFigs';
ctrl_no   = 00;
%%% end of control panel %%%

% ============================ control running time =====================
% --- M must be 3's multiples, 3, 6, 9, etc. ----------
M = 3 * m; %  M<=1,200   % # of sensors
% noiseVSF =( randn(1200, 12000) + 1j* randn(1200, 12000) )/sqrt(2);
% save noiseVSF.mat noiseVSF; 
% load noiseVSF.mat noiseVSF; % maximum 1,200 * 12,000, max 12,000 columns
t_samples = 2*M;  % maximum t_samples == 12,000;   % # of snapshots
% noisenew = noiseVSF(1:M, 1 : t_samples);
% === New methods, generate each time 
noisenew = ( randn(M, t_samples) + 1j* randn(M, t_samples) )/sqrt(2);
% ======================================================================


% Construct the linear system:
f         = (0:1:(scansize-1));
t         = 0:1:(m-1);
A         = exp((-1i*2*pi/scansize)*t'*f);


s         = zeros(scansize,1);
ave_snr   = 10;
% randamp   = 10^(ave_snr/20)*(randn(50,1)+1i*randn(50,1))/sqrt(2);
% randamp2  = 5*exp(rand(50,1)*1i*2*pi)+randamp;
% save randamp2.mat randamp2
load randamp.mat randamp
% rno       = randperm(floor(scansize));
% save rno.mat rno

load rno.mat rno;

source_no     = 10; % maximum 50 sources
s(rno(1:source_no)) = randamp(1:source_no,1);

% ---------------------------
% A is hydrophone Array Manifold matrix
% A_tilde is the Vector Sensor Array Manifold Matrix
u2 = 0: 1/scansize: (1- 1/scansize); % sin values
u3 = sqrt(1-u2.^2); % cos values
u = [ones(1, scansize); u2; u3];
A_tilde = kron(  A, ones(3,1)) .* repmat(u, m,1);
y_noisefree = A_tilde * s;





y_noisy   = repmat(y_noisefree,1,t_samples) + noisenew; %/noisepower_inv;
part_no   = 1;




% 1. DAS - MS

p_hat_das  = sum(abs(A_tilde'*y_noisy/M), 2 )/t_samples;
% s_hat_das  = s_hat_das(1:scansize);
figure;
plot(20*log10(abs(s)+eps), 'xk','MarkerSize',10,'LineWidth',2); hold on;
plot(20*log10( p_hat_das ) , 'g');  axis([-inf inf -50 30]); 
hold on;
axis([-inf inf -50 30]);
legend('Ground Truth', 'DAS', 'Location', 'Northwest');
title('P+V');








% * SlowSPICE (i.e., the ``direct implementation of SPICE'')
Iter_no     = 20; 
tic;
[P ]        = fun_slowSPICE_VSF_new(y_noisy, A_tilde, Iter_no); 
slowSPICEtime = toc;
figure;
plot(20*log10(abs(s)+eps), 'xk','MarkerSize',10,'LineWidth',2); hold on;
plot(20*log10(sqrt(P)), 'b'); axis([-inf inf -50 30]); 
disp('--------------------------');
disp(['SlowSPICE for VSF time == ', num2str(slowSPICEtime)]);
axis([-inf inf -50 30]);
legend('Ground Truth', 'SPICE', 'Location', 'Northwest');
title('P+V');





% 4. fastSPICE
Iter_no     = 20; 
tic;
[P ]        = fun_fastSPICE_VSF_new(y_noisy, A,u, Iter_no); 
fastSPICEtime = toc;
disp('--------------------------');
disp(['fastSPICE for VSF time == ', num2str(fastSPICEtime)]);

figure;
plot(20*log10(abs(s)+eps), 'xk','MarkerSize',10,'LineWidth',2); hold on;
axis([-inf inf -50 30]); 
ylabel('Power / dB');
% 
% 
plot(20*log10(sqrt(P)), 'r'); axis([-inf inf -50 30]); 
legend('Ground Truth', 'SPICE-GS', 'Location', 'Northwest');
title('P+V');

return
