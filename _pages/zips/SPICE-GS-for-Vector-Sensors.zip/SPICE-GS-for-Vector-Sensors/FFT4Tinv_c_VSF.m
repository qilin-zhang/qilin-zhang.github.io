%{
# MATLAB Implementaton Code for "SPICE-GS" in [1] and [2]
These codes are hosted as a zip file on author's personal website: https://qilin-zhang.github.io/publications/, and author's contact: https://qilin-zhang.github.io/contact/.
# OS and software settings
This software was tested on MATLAB back in 2010. Also it is tested to be compatible with Free Open source alternative, GNU Octave Version: 4.2.2, on Ubuntru Linux 18.04 in 2019.
# Citations
If you find the codes helpful, please consider citing the follwing publications, 
[2] Fast implementation of sparse iterative covariance-based estimation for source localization
Zhang, Qilin, Habti Abeida, Ming Xue, William Rowe, and Jian Li. “Fast implementation of sparse iterative covariance-based estimation for source localization.” The Journal of the Acoustical Society of America 131, no. 2 (2012): 1249-1259. 

@article{zhang2012fast,
  title={Fast implementation of sparse iterative covariance-based estimation for source localization},
  author={Zhang, Qilin and Abeida, Habti and Xue, Ming and Rowe, William and Li, Jian},
  journal={The Journal of the Acoustical Society of America},
  volume={131},
  number={2},
  pages={1249--1259},
  year={2012},
  publisher={Acoustical Society of America}
}

preprint PDF link: https://qilin-zhang.github.io/_pages/pdfs/Fast_implementation_of_sparse_iterative_covariance-based_estimation_for_source_localization.pdf?raw=true

[1] Fast implementation of sparse iterative covariance-based estimation for array processing
Zhang, Qilin, Habti Abeida, Ming Xue, William Rowe, and Jian Li. “Fast implementation of sparse iterative covariance-based estimation for array processing.” In Signals, Systems and Computers (ASILOMAR), 2011 Conference Record of the Forty Fifth Asilomar Conference on, pp. 2031-2035. IEEE, 2011. 

@inproceedings{zhang2011fast,
  title={Fast implementation of sparse iterative covariance-based estimation for array processing},
  author={Zhang, Qilin and Abeida, Habti and Xue, Ming and Rowe, William and Li, Jian},
  booktitle={Signals, Systems and Computers (ASILOMAR), 2011 Conference Record of the Forty Fifth Asilomar Conference on},
  pages={2031--2035},
  year={2011},
  organization={IEEE}
}

preprint PDF link: https://qilin-zhang.github.io/_pages/pdfs/Fast_Implementation_of_Sparse_Iterative_Covariance-Based_Estimation_for_Array_Processing.pdf?raw=true

- Note: [2] is the extended journal version of [1].
# Where to start 
1. curve.m: This is the MATLAB/Octave script file to generate plots similar to Fig. 1(d)~(f) and Fig. 2 (b) in [2], the ''actual running time'' values will be different due to different hardware/software settings.
2. tryonceTime.m: In this function, DOA estimation figures are plotted, and actual running time values are recorded.
3. fun_slowSPICE_VSF_new.m: this function is the "direct implementation of SPICE" with Vector Sensor arrays.
4. fun_fastSPICE_VSF_new: the fast version, i.e., SPICE-GS with Vector Sensor arrays. 
5. generatorR_VSF.m: core G-S algorithm implementations, please refer to [2] for details. 
6. FFT4Tinv_c_VSF: core G-S algorithm implementations, please refer to [2] for details. 

# Disclaimer and License
MIT License
Copyright (c) 2010 Qilin Zhang
%}
function [Rinv_Vec_prod] = FFT4Tinv_c_VSF(Acol, Arow, Bcol, Brow, y_noisy)
% compute Rinv * vector  product

% [M1, d1] = size(Acol);
% [d2, M2] = size(Arow);
% if norm(d1-d2) > 10*eps
%     error('Not matched d1 and d2');
% elseif norm(M1 - M2) > 10*eps
%     error('Not Matched M1 and M2');
% else
%     M = M1;
%     d = d1;
% end

 [M, d] = size(Acol);

% ======== Now  R is M-by-M matrix, block size is d ============


% ---------------- correct Brow, Bcol -------------
Brow = [zeros(d,d), Brow(:, 1:end-d)];
Bcol = [zeros(d,d); Bcol(1:end-d, :)];



% ------------------------ begin computing -----------------
pos_x = cell(d,1);
z1_sum = cell(d,1);
pos_x_sum = zeros(M,1);
for idx = 1:d
    pos_x{idx} = zeros(M,1);
    % ------------ compute -----------------
    z1 = cell(d,1);
    z1_sum{idx} = zeros(M/d,1);
    for ind = 1:d
        z1{ind} = fun_TopVecProd(Arow(idx, ind:d:end), [Arow(idx, ind), zeros(1,M/d-1)]', y_noisy(ind:d:end));
        z1_sum{idx} = z1_sum{idx} + z1{ind}; % sum
    end
    
    z2 = cell(d,1);
    for ind = 1:d
        z2{ind} = fun_TopVecProd([Acol(ind, idx),zeros(1,M/d-1)], Acol(ind:d:end, idx),  z1_sum{idx});
    end
    
    for tempi = 1:d
        pos_x{idx}(tempi:d:end) = z2{tempi};
    end
pos_x_sum = pos_x_sum + pos_x{idx};    
end

neg_x = cell(d,1);
z1_sum = cell(d,1);
neg_x_sum = zeros(M,1);
for idx = 1:d
    neg_x{idx} = zeros(M,1);
    % ------------ compute -----------------
    z1 = cell(d,1);
    z1_sum{idx} = zeros(M/d,1);
    for ind = 1:d
        z1{ind} = fun_TopVecProd(Brow(idx, ind:d:end), [Brow(idx, ind), zeros(1,M/d-1)]', y_noisy(ind:d:end));
        z1_sum{idx} = z1_sum{idx} + z1{ind};
    end
    
    z2 = cell(d,1);
    for ind = 1:d
        z2{ind} = fun_TopVecProd([Bcol(ind, idx),zeros(1,M/d-1)], Bcol(ind:d:end, idx),  z1_sum{idx});
    end
    
    for tempi = 1:d
        neg_x{idx}(tempi:d:end) = z2{tempi};
    end
    neg_x_sum = neg_x_sum + neg_x{idx};
    % ---------- done  -----------
end


Rinv_Vec_prod = pos_x_sum - neg_x_sum;


end % end the test_FFT4Tinv_new_VSF function



% ============= Private Functions =================================

function out = fun_TopVecProd(Trow, Tcol, y)
% compute T * y, where Trow is the 1st row, and Tcol is the 1st col of the
% Toeplitz matirix T using FFT

% % ========== defense coding, for debugging only ==========
% [s1, M1] = size(Trow);
% [M2, s2] = size(Tcol);
% if s1 ~= 1
%     error('row dim not = 1');
% elseif s2 ~= 1
%     error('col dim not = 1');
% elseif M1 ~=M2
%     error('M1 v.s. M2, not matching');
% elseif Trow(1) ~= Tcol(1)
%     error('1st element mismatch');
% end
% % ===================================================
M = size(Tcol,1);
B_col = conj([0, fliplr(Trow(2:end))]');
temp = ifft(fft( [y; zeros(M,1)]) .* fft([Tcol;B_col]));
out = temp(1:M);

end
