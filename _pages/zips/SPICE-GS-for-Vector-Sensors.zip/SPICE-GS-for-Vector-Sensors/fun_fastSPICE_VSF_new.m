%{
# MATLAB Implementaton Code for "SPICE-GS" in [1] and [2]
These codes are hosted as a zip file on author's personal website: https://qilin-zhang.github.io/publications/, and author's contact: https://qilin-zhang.github.io/contact/.
# OS and software settings
This software was tested on MATLAB back in 2010. Also it is tested to be compatible with Free Open source alternative, GNU Octave Version: 4.2.2, on Ubuntru Linux 18.04 in 2019.
# Citations
If you find the codes helpful, please consider citing the follwing publications, 
[2] Fast implementation of sparse iterative covariance-based estimation for source localization
Zhang, Qilin, Habti Abeida, Ming Xue, William Rowe, and Jian Li. “Fast implementation of sparse iterative covariance-based estimation for source localization.” The Journal of the Acoustical Society of America 131, no. 2 (2012): 1249-1259. 

@article{zhang2012fast,
  title={Fast implementation of sparse iterative covariance-based estimation for source localization},
  author={Zhang, Qilin and Abeida, Habti and Xue, Ming and Rowe, William and Li, Jian},
  journal={The Journal of the Acoustical Society of America},
  volume={131},
  number={2},
  pages={1249--1259},
  year={2012},
  publisher={Acoustical Society of America}
}

preprint PDF link: https://qilin-zhang.github.io/_pages/pdfs/Fast_implementation_of_sparse_iterative_covariance-based_estimation_for_source_localization.pdf?raw=true

[1] Fast implementation of sparse iterative covariance-based estimation for array processing
Zhang, Qilin, Habti Abeida, Ming Xue, William Rowe, and Jian Li. “Fast implementation of sparse iterative covariance-based estimation for array processing.” In Signals, Systems and Computers (ASILOMAR), 2011 Conference Record of the Forty Fifth Asilomar Conference on, pp. 2031-2035. IEEE, 2011. 

@inproceedings{zhang2011fast,
  title={Fast implementation of sparse iterative covariance-based estimation for array processing},
  author={Zhang, Qilin and Abeida, Habti and Xue, Ming and Rowe, William and Li, Jian},
  booktitle={Signals, Systems and Computers (ASILOMAR), 2011 Conference Record of the Forty Fifth Asilomar Conference on},
  pages={2031--2035},
  year={2011},
  organization={IEEE}
}

preprint PDF link: https://qilin-zhang.github.io/_pages/pdfs/Fast_Implementation_of_Sparse_Iterative_Covariance-Based_Estimation_for_Array_Processing.pdf?raw=true

- Note: [2] is the extended journal version of [1].
# Where to start 
1. curve.m: This is the MATLAB/Octave script file to generate plots similar to Fig. 1(d)~(f) and Fig. 2 (b) in [2], the ''actual running time'' values will be different due to different hardware/software settings.
2. tryonceTime.m: In this function, DOA estimation figures are plotted, and actual running time values are recorded.
3. fun_slowSPICE_VSF_new.m: this function is the "direct implementation of SPICE" with Vector Sensor arrays.
4. fun_fastSPICE_VSF_new: the fast version, i.e., SPICE-GS with Vector Sensor arrays. 
5. generatorR_VSF.m: core G-S algorithm implementations, please refer to [2] for details. 
6. FFT4Tinv_c_VSF: core G-S algorithm implementations, please refer to [2] for details. 

# Disclaimer and License
MIT License
Copyright (c) 2010 Qilin Zhang
%}
function [p] =  fun_fastSPICE_VSF_new(y_noisy_all, A,u, Iter_no) 
% SPICE-GS with Vector Sensor


[m, N]    = size(A); % N is the scanning point
A_tilde   = kron(  A, ones(3,1)) .* repmat(u, m,1);
M = m*3; % this is the # of sensors
t_samples = size(y_noisy_all, 2); % # of snapshot is denoted by t_sample here

s_hat     = ifft(y_noisy_all, N,1)*(N/M);
p         = sum(s_hat.*conj(s_hat),2)/t_samples;
sigmainit = 1e-3; % random pick a value

% A_tilde   = [A, eye(M) ];
R_hat     = y_noisy_all * y_noisy_all'/ t_samples;
% make R_hat toeplitz using sample mean
R_hat_row = zeros( 1, M);
for setvalue = 1:M
    R_hat_row(setvalue) = mean(diag(R_hat, setvalue -1 ));    
end
R_hat = toeplitz(R_hat_row); % modified R_hat, force toeplitz constraint





% =================== debug ===========
% % % compute weight using FFT and GS factorization
% % [a_nm1, b_nm1_hat, lambda_nm1] = generatorofR(R_hat_row', R_hat_row);
% % 
% % coef_Lemma1   = Lemma1_countingGS_coef(a_nm1, b_nm1_hat, lambda_nm1);
% % phase_shift   = exp(-1i*2*pi*(-M+1)*(0:N-1)).';
% % weight_first  = phase_shift.*fft(coef_Lemma1, N) /t_samples;
% ================== end debug =============
weight_first = zeros(N,1); % col vector  
invR_hat = inv(R_hat);
for widx = 1:N
    a_k = A_tilde(:,widx);
    weight_first(widx) = a_k' * invR_hat * a_k / M;
end






% weight        = [ weight_first' , R_hat_row(1) *ones(1,M )/M ]; 
gamma         = R_hat_row(1) * M;
sigma         = sigmainit; % using SPCIE+, with equal sigma constraint
R_hat_sqrt    = sqrtm(R_hat);

for jj        = 1:Iter_no
    display(['fast SPICE VSF Iteration ',num2str(jj),'...']);

%     ===============debug ====================
    %----------- Prepare ------------------------------------
    P_fft = cell(6,1);

    P_fft{1} = fft(p);
    P_fft{1} = P_fft{1}(1:m);

    P_fft{2} = fft(p.* u(2,:)');
    P_fft{2} = P_fft{2}(1:m);

    P_fft{3} = fft(p.* (u(2,:).^2)');
    P_fft{3} = P_fft{3}(1:m);

    P_fft{4} = fft(p.* u(3,:)');
    P_fft{4} = P_fft{4}(1:m);

    P_fft{5} = fft(p.* (u(2,:).*u(3,:))');
    P_fft{5} = P_fft{5}(1:m);

    P_fft{6} = fft(p.* (u(3,:).^2)');
    P_fft{6} = P_fft{6}(1:m);


    R2_1stBlkCol = zeros(M, 3);
    R2_1stBlkCol(1:3:end, 1) = P_fft{1};
    R2_1stBlkCol(2:3:end, 1) = P_fft{2};
    R2_1stBlkCol(2:3:end, 2) = P_fft{3};
    R2_1stBlkCol(3:3:end, 1) = P_fft{4}; 
    R2_1stBlkCol(3:3:end, 2) = P_fft{5};
    R2_1stBlkCol(3:3:end, 3) = P_fft{6};
    % --- symmetric -----------
    R2_1stBlkCol(1:3:end, 2) = P_fft{2};
    R2_1stBlkCol(1:3:end, 3) = P_fft{4}; 
    R2_1stBlkCol(2:3:end, 3) = P_fft{5};

% % %     P_fft       = fft(P);
% % %     R_1stcol    = P_fft(1:M); 

%     ---- diagonal loading --- 
    R2_1stBlkCol(1, 1) = R2_1stBlkCol(1, 1) + sigma;
    R2_1stBlkCol(2, 2) = R2_1stBlkCol(2, 2) + sigma;
    R2_1stBlkCol(3, 3) = R2_1stBlkCol(3, 3) + sigma;
%     R_1stcol(1) =  R_1stcol(1) + sigma;


%     The generators of R_inv, complexity is 2(M^2)-...
    [Acol, Arow, Bcol, Brow] = generatorR_VSF(R2_1stBlkCol); % to go
    
 
    
    %----------- Compute rho ---------------------------
    
%     compute R^{-1} * Rhat
    Rinv_R_hat_sqrt             = zeros(M,M);
    for colidx = 1: M
    Rinv_R_hat_sqrt(:,colidx)   = FFT4Tinv_c_VSF(Acol, Arow, Bcol, Brow, R_hat_sqrt(:,colidx) ); % to go
    end
    %============== theend of debug =====================


% % %     -------- old slow way of compute -------
%     R_dbg         = A * diag(P) * A' + sigma * eye(M);
%     Rinv_R_hat_sqrt_dbg = R_dbg\R_hat_sqrt;
% % %     ---------- end old slow way ------------------
    
    
    % compute F-norm w.r.t the M by M matrix
    norm_Rinv_R_hat_sqrt        = sqrt(  sum(sum(Rinv_R_hat_sqrt .*conj(Rinv_R_hat_sqrt )))  );
    
    % compute A^H * R^{-1} * Rhat using FFT
    % old way: Ah_Rinv_R_hat_sqrt          = ifft(Rinv_R_hat_sqrt, N, 1)*N; % note here, each col vector is useful
    Ah_Rinv_R_hat_sqrt_1 =          ifft(Rinv_R_hat_sqrt(1:3:end,:), N, 1)* N ;
    Ah_Rinv_R_hat_sqrt_2 = repmat(u(2,:)',1, M )   .* (  ifft(Rinv_R_hat_sqrt(2:3:end,:), N, 1)* N );
    Ah_Rinv_R_hat_sqrt_3 = repmat(u(3,:)',1, M ).* (  ifft(Rinv_R_hat_sqrt(3:3:end,:), N, 1)* N );
    Ah_Rinv_R_hat_sqrt = Ah_Rinv_R_hat_sqrt_1 + Ah_Rinv_R_hat_sqrt_2 + Ah_Rinv_R_hat_sqrt_3 ;
    
    
    
    
    % compute the F-norm w.r.t column vecotr
    norm_Ah_Rinv_R_hat_sqrt     = sqrt(   sum(Ah_Rinv_R_hat_sqrt .* conj(Ah_Rinv_R_hat_sqrt), 2)  );
    
    
    % --- rho -----------
    rho                         = sum( sqrt(weight_first) .* p .* norm_Ah_Rinv_R_hat_sqrt );
    rho                         = rho + sqrt(gamma) * sigma * norm_Rinv_R_hat_sqrt;
    
    
    % ---------------- compute sigma -------
    sigma                       = sigma * norm_Rinv_R_hat_sqrt / (sqrt(gamma) * rho  );
    
    % ------------------ compute P ---------
    p                           = p.* norm_Ah_Rinv_R_hat_sqrt ./ (rho * sqrt(weight_first) );
    p = abs(p);
end

