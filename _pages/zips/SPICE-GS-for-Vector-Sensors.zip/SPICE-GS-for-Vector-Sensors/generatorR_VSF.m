%{
# MATLAB Implementaton Code for "SPICE-GS" in [1] and [2]
These codes are hosted as a zip file on author's personal website: https://qilin-zhang.github.io/publications/, and author's contact: https://qilin-zhang.github.io/contact/.
# OS and software settings
This software was tested on MATLAB back in 2010. Also it is tested to be compatible with Free Open source alternative, GNU Octave Version: 4.2.2, on Ubuntru Linux 18.04 in 2019.
# Citations
If you find the codes helpful, please consider citing the follwing publications, 
[2] Fast implementation of sparse iterative covariance-based estimation for source localization
Zhang, Qilin, Habti Abeida, Ming Xue, William Rowe, and Jian Li. “Fast implementation of sparse iterative covariance-based estimation for source localization.” The Journal of the Acoustical Society of America 131, no. 2 (2012): 1249-1259. 

@article{zhang2012fast,
  title={Fast implementation of sparse iterative covariance-based estimation for source localization},
  author={Zhang, Qilin and Abeida, Habti and Xue, Ming and Rowe, William and Li, Jian},
  journal={The Journal of the Acoustical Society of America},
  volume={131},
  number={2},
  pages={1249--1259},
  year={2012},
  publisher={Acoustical Society of America}
}

preprint PDF link: https://qilin-zhang.github.io/_pages/pdfs/Fast_implementation_of_sparse_iterative_covariance-based_estimation_for_source_localization.pdf?raw=true

[1] Fast implementation of sparse iterative covariance-based estimation for array processing
Zhang, Qilin, Habti Abeida, Ming Xue, William Rowe, and Jian Li. “Fast implementation of sparse iterative covariance-based estimation for array processing.” In Signals, Systems and Computers (ASILOMAR), 2011 Conference Record of the Forty Fifth Asilomar Conference on, pp. 2031-2035. IEEE, 2011. 

@inproceedings{zhang2011fast,
  title={Fast implementation of sparse iterative covariance-based estimation for array processing},
  author={Zhang, Qilin and Abeida, Habti and Xue, Ming and Rowe, William and Li, Jian},
  booktitle={Signals, Systems and Computers (ASILOMAR), 2011 Conference Record of the Forty Fifth Asilomar Conference on},
  pages={2031--2035},
  year={2011},
  organization={IEEE}
}

preprint PDF link: https://qilin-zhang.github.io/_pages/pdfs/Fast_Implementation_of_Sparse_Iterative_Covariance-Based_Estimation_for_Array_Processing.pdf?raw=true

- Note: [2] is the extended journal version of [1].
# Where to start 
1. curve.m: This is the MATLAB/Octave script file to generate plots similar to Fig. 1(d)~(f) and Fig. 2 (b) in [2], the ''actual running time'' values will be different due to different hardware/software settings.
2. tryonceTime.m: In this function, DOA estimation figures are plotted, and actual running time values are recorded.
3. fun_slowSPICE_VSF_new.m: this function is the "direct implementation of SPICE" with Vector Sensor arrays.
4. fun_fastSPICE_VSF_new: the fast version, i.e., SPICE-GS with Vector Sensor arrays. 
5. generatorR_VSF.m: core G-S algorithm implementations, please refer to [2] for details. 
6. FFT4Tinv_c_VSF: core G-S algorithm implementations, please refer to [2] for details. 

# Disclaimer and License
MIT License
Copyright (c) 2010 Qilin Zhang
%}
function [Acol, Arow, Bcol, Brow] = generatorR_VSF(L_1st_blkCol ) % 
%


%% ----------- Init values that could be set before hand -----------------
d = 3; % size of the target block



MaxDim = size(L_1st_blkCol, 1)/3 - 1;
R0 = L_1st_blkCol(1:d, :); 

Rn = cell(MaxDim,1); % lower blocks
for ind = 1: MaxDim
    Rn{ind} = L_1st_blkCol(ind*3+1:(ind+1)*3 ,:); 
end

R = cell(MaxDim,1); % diag and upper blocks
for ind = 1: MaxDim
    R{ind} = conj(Rn{ind});
end

% L = cell(MaxDim + 1,1); % block Toepltiz matrices

L{2} = [...
    R0, R{1};...
    Rn{1}, R0];

% % for debug reasons, enable L{3} for now
% L{3} = [ ...
%     R0, R{1}, R{2};...
%     Rn{1}, R0, R{1};...
%     Rn{2}, Rn{1}, R0];

% L{4} = [...
%     R0, R{1}, R{2}, R{3};...
%     Rn{1}, R0, R{1}, R{2};...
%     Rn{2}, Rn{1}, R0, R{1};...
%     Rn{3}, Rn{2}, Rn{1}, R0];

% % L{5} 
% Ltest = [...
%     R0,     R{1},   R{2},   R{3},   R{4};...
%     Rn{1},  R0,     R{1},   R{2},   R{3};...
%     Rn{2},  Rn{1},  R0,     R{1},   R{2};...
%     Rn{3},  Rn{2},  Rn{1},  R0,     R{1};...
%     Rn{4},  Rn{3},  Rn{2},  Rn{1},  R0   ];


% % ----  construct the last L{MaxDim + 1} for computing time comparsion ----
% L{MaxDim + 1} = zeros(d*(MaxDim + 1), d*(MaxDim + 1));
% % main diag
% for diagind = 1: MaxDim +1
%     L{MaxDim + 1}(1+(diagind-1)*d  :diagind*d ,  1+(diagind-1)*d : diagind*d  ) = R0;
% end
% 
% 
% % assign rest of upper part
% for  rind = 1: MaxDim
%     for cind = rind + 1: MaxDim+1
%         L{MaxDim + 1}( (rind-1)*d+1 : rind*d  , (cind-1)*d+1 : cind*d  ) =  R{cind - rind};
%     end
% end
%     
% for  cind = 1: MaxDim
%     for rind = cind + 1: MaxDim+1
%         L{MaxDim + 1}( (rind-1)*d+1 : rind*d  , (cind-1)*d+1 : cind*d  ) =  Rn{rind - cind};
%     end
% end
% % ---------- Finish constructing L{MaxDim + 1}  -------------------------
% Lout = L{MaxDim + 1};




%% ===================================================================
%  pre store these things
%  define h_r{}, a{},  t_h_a{}, t_r{}
h_r = cell(MaxDim, 1);
a_  = cell(MaxDim, 1);
t_r = cell(MaxDim, 1);
t_h_a = cell(MaxDim, 1);



% ----------- use a naive loop to generate these values --------
h_r{1}    = Rn{1};
a_{1}     = R{1};
t_h_a{1}  = R{1};
t_r{1}    = Rn{1};

for ind = 2: MaxDim
    h_r{ind} = [ Rn{ind} ;h_r{ind-1}];
    a_{ind} = [a_{ind-1}; R{ind}];
    t_h_a{ind} = [R{ind}, t_h_a{ind-1}];
    t_r{ind} = [t_r{ind-1}, Rn{ind}];
end



%% -----------   Begin iterations       ------------------------

% initial
q_inv = cell(MaxDim,1); % compute during iter
s_inv = cell(MaxDim,1); % compute during iter



% ********** extra computing power saving trick **************
% keep a copy of the inversion of the matrix, save some time
q_  = cell(MaxDim,1); % compute during iter
s_  = cell(MaxDim,1); % compute during iter




% ******************** end of the trick **********

% ---- direct computing of the 2 blocks-matrix -------
L_2_inv = inv(L{2});
L_2_BT_inv = inv(BTp(L{2}, d));

q_{1} = L_2_inv(1:d,1:d);
q_inv{1} = inv(q_{1});
s_{1} = L_2_BT_inv(1:d,1:d);
s_inv{1} = inv(s_{1});

% ------------------------------------------

t_l = cell(MaxDim,1); % compute during iter
t_h_f = cell(MaxDim,1); % compute during iter



t_l{1} = L_2_BT_inv(1:d, d+1:end);
t_h_f{1} = L_2_BT_inv(end-d+1: end, 1:end-d);



j_ = cell(MaxDim, 1); % compute during iter
h_h = cell(MaxDim, 1);  % compute during iter


j_{1} = L_2_BT_inv(d+1:end, 1:d);
h_h{1} = L_2_BT_inv(1:end-d, end-d+1:end);


% ------ Prealloc space for 3.18, 3.20 ~ 3.22 --------------
t_alpha = cell(MaxDim, 1);
t_beta = cell(MaxDim, 1);
gamma = cell(MaxDim, 1);
delta = cell(MaxDim, 1);


for p = 1: (MaxDim-1) % use p as iteration index, from 1 NOW! 

        
        % --- 
        t_alpha{p+1} = [s_inv{p} * t_l{p} , zeros(d,d) ] - ( (s_inv{p} * t_l{p} )* h_r{p}    + Rn{p+1} ) * q_{p} * [q_inv{p} * t_h_f{p}  , eye(d) ] ;
        t_beta{p+1} = [zeros(d,d), q_inv{p} * t_h_f{p} ] - (R{p+1} + (q_inv{p}*t_h_f{p}) * a_{p}  ) * s_{p} *  [eye(d), s_inv{p} * t_l{p}];
        gamma{p+1} = [j_{p}*s_inv{p} ; zeros(d,d)] - [h_h{p}*q_inv{p}   ; eye(d)]* q_{p} * (R{p+1} + t_h_a{p}*(j_{p} * s_inv{p}  ));
        delta{p+1} = [zeros(d,d)  ; h_h{p}*q_inv{p} ] - [eye(d) ; j_{p}*s_inv{p}] * s_{p} * (t_r{p}*(h_h{p}*q_inv{p}  ) + Rn{p+1}  );
        
        % ---- update q_inv{}, s_inv{}, i.e., 3,23 and 3.24, then compute
        % q_{} and s_{} to save time 
        q_inv{p+1} = q_inv{p} - (t_beta{p+1}(1:d, 1:d)) * ( t_alpha{p+1}(end-d+1:end, end-d+1:end)) * q_inv{p};
        s_inv{p+1} = s_inv{p} - (t_alpha{p+1}(end-d+1:end, end-d+1:end)) *  (t_beta{p+1}(1:d,1:d)) * s_inv{p};
        q_{p+1} = inv(q_inv{p+1});
        s_{p+1} = inv(s_inv{p+1});
        
        % --- update t_l{}, t_h_f{}, j_{}, h_h{}  for next iteration 
        t_l{p+1} = s_{p+1} * t_alpha{p+1};
        t_h_f{p+1} = q_{p+1} * t_beta{p+1};
        j_{p+1} = gamma{p+1} * s_{p+1};
        h_h{p+1} = delta{p+1} * q_{p+1};
        
        % ------- clear more memory  ---- when debug, disable these ---
        t_l{p} =[];
        t_h_f{p} = [];
        j_{p} = [];
        h_h{p} = [];
        s_{p} = [];
        q_inv{p} = [];
        s_inv{p} = [];
        q_{p} = [];
        t_alpha{p} = [];
        t_beta{p} = [];
        gamma{p} = [];
        delta{p} = [];
        
   
    
end % end for, end iteration in dimensions


wn = Browflip(gamma{MaxDim} * s_{MaxDim}  ,d) * s_inv{MaxDim};
vn_BT = s_inv{MaxDim} * Bcolflip(s_{MaxDim} * t_alpha{MaxDim}  ,d);
Bcol = [ wn * s_{MaxDim}; s_{MaxDim}];
Brow = [vn_BT, eye(d)];


% % ============ For debug =============
% disp('=== compute === ');
% disp(Bcol * Brow);
% disp('real ======');
% disp(inv(L{MaxDim+1}));
% % ============= End for Debug ============

Vn_BT = q_inv{MaxDim} * Bcolflip(q_{MaxDim} * t_beta{MaxDim}  , d);
Wn = Browflip(delta{MaxDim} * q_{MaxDim}  ,d) * q_inv{MaxDim}; 
Acol = [q_{MaxDim}; Wn * q_{MaxDim}];
Arow = [eye(d), Vn_BT];

% % ============ For debug =============
% disp('=== compute === ');
% disp(Acol * Arow);
% disp('real ======');
% disp(inv(L{MaxDim+1}));
% % ============= End for Debug ============







% disp('Add Break point here for debug');
end % end main function







% ########################### Private Functions ####################

function out = BTp(in, p)
% block transpose for blocksize p 

[M, N] = size(in);

% % ======== debug only ===============
% if mod(M, p) ~= 0
%     disp('error row size');
% elseif mod(N, p) ~= 0
%     disp('error col size');
% end
% % ========== end debug code =========


out = zeros(N, M);
for ridx = 0: M/p - 1
    for cidx = 0: N/p -1
        out(cidx*p+1: cidx*p+p, ridx*p+1: ridx*p +p  ) = in(ridx*p + 1: ridx*p + p, cidx*p+1: cidx *p + p );
    end
end

end % end function Block transpose



function out = Browflip(in, p)
% \hat{} operation, i.e., row wise block flipupside down
[M, N] = size(in);
out = zeros(M,N);
for ridx = 0: M/p - 1
    out(ridx*p+1: ridx*p+p, : ) = in(M - (ridx+1)*p + 1: M-ridx*p, :);
end

end % end row-wise flipud function

function out = Bcolflip(in, p)
% \hat{} operation with a extra tilde used first, i.e., col. wise block flipupside down
[M, N] = size(in);
out = zeros(M,N);
for cidx = 0: N/p - 1
    out(:, cidx*p+1: cidx*p+p) = in(:, N - (cidx+1)*p + 1: N-cidx*p);
end

end % end row-wise flipud function


% Note the above 2 private function will yield the same results for a given
% matrix Q: BTp( Browflip(Q, p), p) =======  Bcolflip( BTp(Q,p), p)


