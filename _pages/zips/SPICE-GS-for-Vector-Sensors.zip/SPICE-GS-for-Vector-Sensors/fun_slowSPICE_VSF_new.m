%{
# MATLAB Implementaton Code for "SPICE-GS" in [1] and [2]
These codes are hosted as a zip file on author's personal website: https://qilin-zhang.github.io/publications/, and author's contact: https://qilin-zhang.github.io/contact/.
# OS and software settings
This software was tested on MATLAB back in 2010. Also it is tested to be compatible with Free Open source alternative, GNU Octave Version: 4.2.2, on Ubuntru Linux 18.04 in 2019.
# Citations
If you find the codes helpful, please consider citing the follwing publications, 
[2] Fast implementation of sparse iterative covariance-based estimation for source localization
Zhang, Qilin, Habti Abeida, Ming Xue, William Rowe, and Jian Li. “Fast implementation of sparse iterative covariance-based estimation for source localization.” The Journal of the Acoustical Society of America 131, no. 2 (2012): 1249-1259. 

@article{zhang2012fast,
  title={Fast implementation of sparse iterative covariance-based estimation for source localization},
  author={Zhang, Qilin and Abeida, Habti and Xue, Ming and Rowe, William and Li, Jian},
  journal={The Journal of the Acoustical Society of America},
  volume={131},
  number={2},
  pages={1249--1259},
  year={2012},
  publisher={Acoustical Society of America}
}

preprint PDF link: https://qilin-zhang.github.io/_pages/pdfs/Fast_implementation_of_sparse_iterative_covariance-based_estimation_for_source_localization.pdf?raw=true

[1] Fast implementation of sparse iterative covariance-based estimation for array processing
Zhang, Qilin, Habti Abeida, Ming Xue, William Rowe, and Jian Li. “Fast implementation of sparse iterative covariance-based estimation for array processing.” In Signals, Systems and Computers (ASILOMAR), 2011 Conference Record of the Forty Fifth Asilomar Conference on, pp. 2031-2035. IEEE, 2011. 

@inproceedings{zhang2011fast,
  title={Fast implementation of sparse iterative covariance-based estimation for array processing},
  author={Zhang, Qilin and Abeida, Habti and Xue, Ming and Rowe, William and Li, Jian},
  booktitle={Signals, Systems and Computers (ASILOMAR), 2011 Conference Record of the Forty Fifth Asilomar Conference on},
  pages={2031--2035},
  year={2011},
  organization={IEEE}
}

preprint PDF link: https://qilin-zhang.github.io/_pages/pdfs/Fast_Implementation_of_Sparse_Iterative_Covariance-Based_Estimation_for_Array_Processing.pdf?raw=true

- Note: [2] is the extended journal version of [1].
# Where to start 
1. curve.m: This is the MATLAB/Octave script file to generate plots similar to Fig. 1(d)~(f) and Fig. 2 (b) in [2], the ''actual running time'' values will be different due to different hardware/software settings.
2. tryonceTime.m: In this function, DOA estimation figures are plotted, and actual running time values are recorded.
3. fun_slowSPICE_VSF_new.m: this function is the "direct implementation of SPICE" with Vector Sensor arrays.
4. fun_fastSPICE_VSF_new: the fast version, i.e., SPICE-GS with Vector Sensor arrays. 
5. generatorR_VSF.m: core G-S algorithm implementations, please refer to [2] for details. 
6. FFT4Tinv_c_VSF: core G-S algorithm implementations, please refer to [2] for details. 

# Disclaimer and License
MIT License
Copyright (c) 2010 Qilin Zhang
%}
function [p] = fun_slowSPICE_VSF_new(y_noisy_all, A, Iter_no) 
% SPICE with Vector Sensor 

[M, N]    = size(A);
t_samples = size(y_noisy_all, 2); % # of snapshot is denoted by t_sample here

% DAS - MS init
p         = sum(abs(A'*y_noisy_all/M), 2 )/t_samples;

sigmainit = 1e-3; % random pick a value


R_hat     = y_noisy_all * y_noisy_all'/ t_samples;
% make R_hat toeplitz using sample mean
R_hat_row = zeros( 1, M);
for setvalue = 1:M
    R_hat_row(setvalue) = mean(diag(R_hat, setvalue -1 ));    
end
R_hat = toeplitz(R_hat_row); % modified R_hat, force toeplitz constraint


invR_hat = inv(R_hat);
% compute weight using conventional way

weight_first = zeros(1, N); % row vector 
for widx = 1:N
    a_k = A(:,widx);
    weight_first(widx) = a_k' * invR_hat * a_k / M;
end

weight        = [ weight_first , R_hat_row(1) *ones(1,M )/M ]; 
gamma         = R_hat_row(1) * M;
sigma         = sigmainit; % using SPCIE+, with equal sigma constraint


for jj        = 1:Iter_no
    display(['=== Slow SPICE VSF Iteration ',num2str(jj),'...']);
    
    % ----------- Prepare ------------------------------------
    P         = diag(p);
    R         = A * P * A' + sigma * eye(M);
    Rinv_R_hat_sqrt = R\sqrtm(R_hat);
    
    
    % ------------ compute rho ----------------------------
    rho =0;
    
    am_Rinv_R_hat_sqrt = zeros(N , M); 
    norm_am_Rinv_R_hat_sqrt = zeros(N , 1); % save for future use
    for idx = 1: N
        am_Rinv_R_hat_sqrt(idx,:) = A(:,idx)' * Rinv_R_hat_sqrt; 
        norm_am_Rinv_R_hat_sqrt(idx) = sqrt(sum(diag(am_Rinv_R_hat_sqrt(idx,:) * am_Rinv_R_hat_sqrt(idx,:)' )));
        rho = rho + sqrt(weight(idx)) * p(idx) * norm_am_Rinv_R_hat_sqrt(idx);
    end
    % keep the  || ||F for future use
    norm_Rinv_Rhatsqrt = sqrt(sum( diag( Rinv_R_hat_sqrt' * Rinv_R_hat_sqrt ) ) );  % save for future use
    rho = rho + sqrt(gamma) * sigma * norm_Rinv_Rhatsqrt;
    
    
    % ------------- compute sigma ---------------------------------
    sigma = sigma * norm_Rinv_Rhatsqrt / (sqrt(gamma) * rho  );
    
   
    
    % --------------- compute p ------------------------------------
    for pidx = 1: N
        p(pidx) = p(pidx) * norm_am_Rinv_R_hat_sqrt(pidx)  / (rho * sqrt(weight(pidx) ) );
    end
    p = abs(p);
end

