% This is the entry point of running all codes
% 
%

%{
# MATLAB Implementaton Code for "SPICE-GS" in [1] and [2]
These codes are hosted as a zip file on author's personal website: https://qilin-zhang.github.io/publications/, and author's contact: https://qilin-zhang.github.io/contact/.
# OS and software settings
This software was tested on MATLAB back in 2010. Also it is tested to be compatible with Free Open source alternative, GNU Octave Version: 4.2.2, on Ubuntru Linux 18.04 in 2019.
# Citations
If you find the codes helpful, please consider citing the follwing publications, 
[2] Fast implementation of sparse iterative covariance-based estimation for source localization
Zhang, Qilin, Habti Abeida, Ming Xue, William Rowe, and Jian Li. “Fast implementation of sparse iterative covariance-based estimation for source localization.” The Journal of the Acoustical Society of America 131, no. 2 (2012): 1249-1259. 

@article{zhang2012fast,
  title={Fast implementation of sparse iterative covariance-based estimation for source localization},
  author={Zhang, Qilin and Abeida, Habti and Xue, Ming and Rowe, William and Li, Jian},
  journal={The Journal of the Acoustical Society of America},
  volume={131},
  number={2},
  pages={1249--1259},
  year={2012},
  publisher={Acoustical Society of America}
}

preprint PDF link: https://qilin-zhang.github.io/_pages/pdfs/Fast_implementation_of_sparse_iterative_covariance-based_estimation_for_source_localization.pdf?raw=true

[1] Fast implementation of sparse iterative covariance-based estimation for array processing
Zhang, Qilin, Habti Abeida, Ming Xue, William Rowe, and Jian Li. “Fast implementation of sparse iterative covariance-based estimation for array processing.” In Signals, Systems and Computers (ASILOMAR), 2011 Conference Record of the Forty Fifth Asilomar Conference on, pp. 2031-2035. IEEE, 2011. 

@inproceedings{zhang2011fast,
  title={Fast implementation of sparse iterative covariance-based estimation for array processing},
  author={Zhang, Qilin and Abeida, Habti and Xue, Ming and Rowe, William and Li, Jian},
  booktitle={Signals, Systems and Computers (ASILOMAR), 2011 Conference Record of the Forty Fifth Asilomar Conference on},
  pages={2031--2035},
  year={2011},
  organization={IEEE}
}

preprint PDF link: https://qilin-zhang.github.io/_pages/pdfs/Fast_Implementation_of_Sparse_Iterative_Covariance-Based_Estimation_for_Array_Processing.pdf?raw=true

- Note: [2] is the extended journal version of [1].
# Where to start 
1. curve.m: This is the MATLAB/Octave script file to generate plots similar to Fig. 1(d)~(f) and Fig. 2 (b) in [2], the ''actual running time'' values will be different due to different hardware/software settings.
2. tryonceTime.m: In this function, DOA estimation figures are plotted, and actual running time values are recorded.
3. fun_slowSPICE_VSF_new.m: this function is the "direct implementation of SPICE" with Vector Sensor arrays.
4. fun_fastSPICE_VSF_new: the fast version, i.e., SPICE-GS with Vector Sensor arrays. 
5. generatorR_VSF.m: core G-S algorithm implementations, please refer to [2] for details. 
6. FFT4Tinv_c_VSF: core G-S algorithm implementations, please refer to [2] for details. 


# Disclaimer and License
MIT License
Copyright (c) 2010 Qilin Zhang
%}


m_set = [0 32]; % this is the default toy-case, runs really fast (<1 minute, but the curve is meaningless, 
                 % the GS-factorization based speed-up is only evident with very large number of sensor points
                 % also: with so few sensors, the DOA estimation is inaccurate, too
%m_set = 0:100:700; % this is the realistic settings, it is extremely slow and may take serval days
M_set = 3.* m_set;
stime = zeros(length(m_set)-1, 1);
ftime = zeros(length(m_set)-1, 1);

for ind = 2:length(m_set)
    [stime(ind), ftime(ind)] =  tryonceTime(m_set(ind));
end

figure;
plot(M_set, stime, '-xg','MarkerSize',15); hold on;
plot(M_set, ftime, '-xr','MarkerSize',15);
legend('SPICE', 'SPICE-GS', 'Location', 'Northwest');
xlabel('Sensor points');
ylabel('Time (sec)');
title('Vector Sensor array')








